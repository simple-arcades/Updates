#!/bin/bash

# Global Constants
MUSIC_FOLDER="/home/pi/RetroPie/music"
SCREENSAVER_FOLDER="/opt/retropie/configs/all/emulationstation/scripts/videos/screensavers"
ES_CONFIG_FILE="/opt/retropie/configs/all/emulationstation/es_settings.cfg"
SELECTED_PLAYLIST_FILE="/home/pi/music_settings/selected_playlist.flag"
SCREENSAVER_CONFIG="$SCREENSAVER_FOLDER/selected_screensavers.conf"
THEME_FOLDER="/etc/emulationstation/themes"
MUTE_LAUNCH_SOUND_FLAG="/home/pi/music_settings/mute_launch_sound.flag"
SCREENSAVER_MUSIC_FLAG="/home/pi/music_settings/music_over_screensaver/onoff.flag"

# Ensure Required Files Exist
ensure_required_files() {
    for file in "$SELECTED_PLAYLIST_FILE" "$SCREENSAVER_CONFIG" "$MUTE_LAUNCH_SOUND_FLAG" "$SCREENSAVER_MUSIC_FLAG"; do
        [[ ! -f $file ]] && touch "$file"
    done
}
ensure_required_files

# Helper Functions
show_message() {
    dialog --ok-button "OK" --msgbox "$1" 10 40
}

update_flag() {
    echo "$2" > "$1"
}

get_flag_value() {
    cat "$1" 2>/dev/null || echo "$2"
}

# Main Menu
main_menu() {
    while true; do
        OPTION=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "Simple Arcades Theme Options" --menu "Choose an option:" 15 60 4 \
            1 "UI Theme Settings" \
            2 "Screensaver Settings" \
            3 "Music Settings" \
            4 "Game Launch Video Settings" \
            3>&1 1>&2 2>&3)

        case $? in
            0)
                case $OPTION in
                    1) ui_theme_settings ;;
                    2) screensaver_settings ;;
                    3) music_settings ;;
                    4) launch_video_settings ;;
                esac
                ;;
            *)
                show_message "Done. Now go play some games! :)"
                exit 0
                ;;
        esac
    done
}

# UI Theme Settings
ui_theme_settings() {
    while true; do
        THEME_LIST=$(find "$THEME_FOLDER" -mindepth 1 -maxdepth 1 -type d | sort)
        [[ -z $THEME_LIST ]] && { show_message "No themes found in $THEME_FOLDER!"; return; }

        CURRENT_THEME=$(sed -n 's/.*<string name="ThemeSet" value="\([^"]*\)".*/\1/p' "$ES_CONFIG_FILE")
        MENU_OPTIONS=()
        COUNTER=1

        while IFS= read -r THEME_PATH; do
            THEME_NAME=$(basename "$THEME_PATH")
            MARK=$([[ $CURRENT_THEME == "$THEME_NAME" ]] && echo " (Currently Selected)")
            MENU_OPTIONS+=("$COUNTER" "$THEME_NAME$MARK")
            ((COUNTER++))
        done <<< "$THEME_LIST"

        THEME_TAG=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "Change UI Theme" --menu "Choose a theme:" 15 60 10 "${MENU_OPTIONS[@]}" 3>&1 1>&2 2>&3)

        # If user presses Cancel, return
        [[ $? -ne 0 ]] && return

        SELECTED_THEME=$(echo "$THEME_LIST" | sed -n "${THEME_TAG}p" | xargs basename)
        if [[ $CURRENT_THEME != "$SELECTED_THEME" ]]; then
            sed -i "s|<string name=\"ThemeSet\" value=\".*\"|<string name=\"ThemeSet\" value=\"$SELECTED_THEME\"|" "$ES_CONFIG_FILE"
            show_message "Theme applied! You must reboot your arcade to see changes."
        else
            show_message "The selected theme is already applied!"
        fi
    done
}

# Screensaver Settings
screensaver_settings() {
    while true; do
        MUSIC_STATUS=$(get_flag_value "$SCREENSAVER_MUSIC_FLAG" 0)
        MUSIC_OPTION=$([[ $MUSIC_STATUS == "1" ]] && echo "Disable Screensaver Music" || echo "Enable Screensaver Music")

        OPTION=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "Screensaver Settings" --menu "Choose an option:" 15 60 2 \
            1 "Screensaver Gallery (Edit Video List)" \
            2 "$MUSIC_OPTION" \
            3>&1 1>&2 2>&3)

        [[ $? -ne 0 ]] && return

        case $OPTION in
            1) screensaver_video_settings ;;
            2)
                NEW_STATUS=$([[ $MUSIC_STATUS == "1" ]] && echo "0" || echo "1")
                update_flag "$SCREENSAVER_MUSIC_FLAG" "$NEW_STATUS"
                show_message "Screensaver music has been $([[ $NEW_STATUS == "1" ]] && echo "enabled" || echo "disabled")."
                ;;
        esac
    done
}

screensaver_video_settings() {
    if ! ls "$SCREENSAVER_FOLDER"/*.mp4 >/dev/null 2>&1; then
        show_message "No screensaver videos found in $SCREENSAVER_FOLDER!"
        return
    fi

    while true; do
        MENU_OPTIONS=("SelectAll" "Select All Videos" "off")
        COUNTER=1

        # Populate MENU_OPTIONS with videos
        for video in "$SCREENSAVER_FOLDER"/*.mp4; do
            FILENAME=$(basename "$video")
            SELECTED=$([[ -f "$SCREENSAVER_CONFIG" && $(grep -Fx "$FILENAME" "$SCREENSAVER_CONFIG") ]] && echo "on" || echo "off")
            MENU_OPTIONS+=("$COUNTER" "$FILENAME" "$SELECTED")
            ((COUNTER++))
        done

        CHOICES=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "Screensaver Video Selection" --checklist \
            "Use your controls as follows:\n\nBack Button: Check Selection\nSelect Button: Save and confirm choices\n" \
            20 60 10 "${MENU_OPTIONS[@]}" 3>&1 1>&2 2>&3)

        [[ $? -ne 0 ]] && return

        if echo "$CHOICES" | grep -q "SelectAll"; then
            > "$SCREENSAVER_CONFIG"
            for video in "$SCREENSAVER_FOLDER"/*.mp4; do
                echo "$(basename "$video")" >> "$SCREENSAVER_CONFIG"
            done
            show_message "All videos selected!"
        else
            echo "$CHOICES" | tr -d '"' | sed 's/ /\n/g' > "$SCREENSAVER_CONFIG"
            show_message "Screensaver video selection updated!"
        fi
    done
}

# Game Launch Video Settings
launch_video_settings() {
    while true; do
        CURRENT_STATUS=$(get_flag_value "$MUTE_LAUNCH_SOUND_FLAG" 0)
        MENU_OPTIONS=("1" "$([[ $CURRENT_STATUS == "1" ]] && echo "Enable Launch Video Sound (Currently Muted)" || echo "Mute Launch Video Sound (Currently Enabled)")")

        OPTION=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "Launch Video Settings" --menu "Configure launch video options:" 15 60 1 "${MENU_OPTIONS[@]}" 3>&1 1>&2 2>&3)

        [[ $? -ne 0 ]] && return

        case $OPTION in
            1)
                NEW_STATUS=$([[ $CURRENT_STATUS == "1" ]] && echo "0" || echo "1")
                update_flag "$MUTE_LAUNCH_SOUND_FLAG" "$NEW_STATUS"
                show_message "Launch video sound has been $([[ $NEW_STATUS == "1" ]] && echo "muted" || echo "enabled")."
                ;;
        esac
    done
}

# Music Settings
music_settings() {
    while true; do
        MENU_OPTIONS=("NoMusic" "No Music (Disable Background Music)")
        COUNTER=1

        FOLDER_LIST=$(find "$MUSIC_FOLDER" -mindepth 1 -maxdepth 1 -type d | sort)
        [[ -z $FOLDER_LIST ]] && { show_message "No playlists found in $MUSIC_FOLDER!"; return; }

        CURRENT_PLAYLIST=$(get_flag_value "$SELECTED_PLAYLIST_FILE" "")

        while IFS= read -r FOLDER; do
            FOLDER_NAME=$(basename "$FOLDER")
            MARK=$([[ $CURRENT_PLAYLIST == "$FOLDER" ]] && echo " (Currently Selected)")
            MENU_OPTIONS+=("$COUNTER" "$FOLDER_NAME$MARK")
            ((COUNTER++))
        done <<< "$FOLDER_LIST"

        PLAYLIST_TAG=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "Soundtrack Selection" --menu "Choose a music playlist:" 15 60 10 "${MENU_OPTIONS[@]}" 3>&1 1>&2 2>&3)
        [[ $? -ne 0 ]] && return

        if [ "$PLAYLIST_TAG" == "NoMusic" ]; then
            update_flag "/home/pi/music_settings/onoff.flag" "0"
            pkill mpg123
            show_message "Background music disabled."
            continue
        fi

        SELECTED_FOLDER=$(echo "$FOLDER_LIST" | sed -n "${PLAYLIST_TAG}p")
        if [[ $CURRENT_PLAYLIST != "$SELECTED_FOLDER" ]]; then
            update_flag "$SELECTED_PLAYLIST_FILE" "$SELECTED_FOLDER"
            update_flag "/home/pi/music_settings/onoff.flag" "1"
            restart_music_player "$SELECTED_FOLDER"
        fi
    done
}

restart_music_player() {
    pkill mpg123
    sleep 1
    if ! ls "$1"/*.mp3 >/dev/null 2>&1; then
        show_message "No .mp3 files found in $1. Music not restarted."
        return
    fi
    mpg123 -Z "$1"/*.mp3 > /dev/null 2>&1 &
    pkill -STOP mpg123
    show_message "Playlist updated!"
}

# Run Main Menu
main_menu