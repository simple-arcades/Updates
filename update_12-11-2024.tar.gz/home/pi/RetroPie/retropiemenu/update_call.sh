#!/bin/bash

# Ensure the script is run as root
sudo /home/pi/RetroPie/custom_scripts/update_system.sh 2>/dev/null