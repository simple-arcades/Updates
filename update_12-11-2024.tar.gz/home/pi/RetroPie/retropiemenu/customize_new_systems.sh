#!/bin/bash

# Prevent multiple instances
LOCKFILE="/var/run/customize_new_systems.lock"

if [ -e "$LOCKFILE" ] && kill -0 "$(cat "$LOCKFILE")" 2>/dev/null; then
    echo "Script is already running."
    exit 1
fi

trap "rm -f $LOCKFILE; exit" INT TERM EXIT
echo $$ > "$LOCKFILE"

# Constants
LOG_FILE="/home/pi/RetroPie/docs/arcade_setup.log"
MARKER_FILE="/home/pi/RetroPie/docs/arcade_configured.txt"
ROM_DIR="/home/pi/RetroPie/roms/mame-libretro"
SCRIPT_DIR="/home/pi/RetroPie/custom_scripts/lists"
EMULATIONSTATION_CONFIG="/opt/retropie/configs/all/emulationstation"

# Logging function
log_action() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

# Cleanup lightgun menu option and delete lightgun games listed in rom_list
cleanup_lightgun() {
    log_action "Running cleanup for lightgun files..."

    local LIGHTGUN_CFG="/opt/retropie/configs/all/emulationstation/collections/custom-lightgun.cfg"
    local ROM_LIST="/home/pi/RetroPie/custom_scripts/lists/lightgun_no_clones.txt"

    # Delete config file
    if [ -f "$LIGHTGUN_CFG" ]; then
        rm -f "$LIGHTGUN_CFG"
        log_action "Deleted lightgun config file: $LIGHTGUN_CFG"
    else
        log_action "Lightgun config file not found: $LIGHTGUN_CFG"
    fi

    # Check if ROM list exists
    if [ ! -f "$ROM_LIST" ]; then
        log_action "ROM list file $ROM_LIST does not exist. Exiting cleanup_lightgun."
        return 1
    fi

    # Delete each ROM listed
    while IFS= read -r rom_file; do
        local rom_path="$ROM_DIR/$rom_file"
        if [ -f "$rom_path" ]; then
            rm -f "$rom_path"
            log_action "Deleted lightgun ROM file: $rom_path"
        else
            log_action "Lightgun ROM file not found: $rom_path"
        fi
    done < "$ROM_LIST"

    log_action "Lightgun cleanup completed."
}

# Cleanup spinner games menu option and delete spinner games listed in rom_list
cleanup_spinner() {
    log_action "Running cleanup for spinner files..."

    local SPINNER_CFG="/opt/retropie/configs/all/emulationstation/collections/custom-spinner.cfg"
    local ROM_LIST="/home/pi/RetroPie/custom_scripts/lists/spinner_no_clones.txt"

    # Delete config file
    if [ -f "$SPINNER_CFG" ]; then
        rm -f "$SPINNER_CFG"
        log_action "Deleted spinner config file: $SPINNER_CFG"
    else
        log_action "Spinner config file not found: $SPINNER_CFG"
    fi

    # Check if ROM list exists
    if [ ! -f "$ROM_LIST" ]; then
        log_action "ROM list file $ROM_LIST does not exist. Exiting cleanup_spinner."
        return 1
    fi

    # Delete each ROM listed
    while IFS= read -r rom_file; do
        local rom_path="$ROM_DIR/$rom_file"
        if [ -f "$rom_path" ]; then
            rm -f "$rom_path"
            log_action "Deleted spinner ROM file: $rom_path"
        else
            log_action "Spinner ROM file not found: $rom_path"
        fi
    done < "$ROM_LIST"

    log_action "Spinner cleanup completed."
}

# Cleanup trackball games menu option and delete trackball games listed in rom_list
cleanup_trackball() {
    log_action "Running cleanup for trackball files..."

    local TRACKBALL_CFG="/opt/retropie/configs/all/emulationstation/collections/custom-trackball.cfg"
    local ROM_LIST="/home/pi/RetroPie/custom_scripts/lists/trackball_no_clones.txt"

    # Delete config file
    if [ -f "$TRACKBALL_CFG" ]; then
        rm -f "$TRACKBALL_CFG"
        log_action "Deleted trackball config file: $TRACKBALL_CFG"
    else
        log_action "Trackball config file not found: $TRACKBALL_CFG"
    fi

    # Check if ROM list exists
    if [ ! -f "$ROM_LIST" ]; then
        log_action "ROM list file $ROM_LIST does not exist. Exiting cleanup_trackball."
        return 1
    fi

    # Delete each ROM listed
    while IFS= read -r rom_file; do
        local rom_path="$ROM_DIR/$rom_file"
        if [ -f "$rom_path" ]; then
            rm -f "$rom_path"
            log_action "Deleted trackball ROM file: $rom_path"
        else
            log_action "Trackball ROM file not found: $rom_path"
        fi
    done < "$ROM_LIST"

    log_action "Trackball cleanup completed."
}

# Cleanup 4 player collection in main menu
cleanup_4p_collection() {
    log_action "Running cleanup for 4P collection files..."
    local FOURP_CFG="/opt/retropie/configs/all/emulationstation/collections/custom-4p.cfg"

    # Delete the custom-4p.cfg file
    if [ -f "$FOURP_CFG" ]; then
        rm -f "$FOURP_CFG"
        log_action "Deleted 4P collection file: $FOURP_CFG"
    else
        log_action "4P collection file not found: $FOURP_CFG"
    fi

    log_action "4P collection cleanup completed."
}

# Cleanup pixelcade functionality and remove files
cleanup_pixelcade() {
    log_action "Running cleanup for Pixelcade files..."

    local pixelcade_dir="/home/pi/pixelcade"
    local achievements_dir="/opt/retropie/configs/all/emulationstation/scripts/achievements"
    local scripts_dir="/opt/retropie/configs/all/emulationstation/scripts"
    local autostart_file="/opt/retropie/configs/all/autostart.sh"
    local pixelcade_line="cd /home/pi/pixelcade && java -jar pixelweb.jar -b -s &"

    # Remove pixelcade directory
    if [ -d "$pixelcade_dir" ]; then
        rm -rf "$pixelcade_dir"
        log_action "Deleted Pixelcade directory: $pixelcade_dir"
    else
        log_action "Pixelcade directory not found: $pixelcade_dir"
    fi

    # Remove achievements directory
    if [ -d "$achievements_dir" ]; then
        rm -rf "$achievements_dir"
        log_action "Deleted Achievements directory: $achievements_dir"
    else
        log_action "Achievements directory not found: $achievements_dir"
    fi

    # Find and delete pixelcade script files
    local pixelcade_files_found=false
    while IFS= read -r file; do
        rm -f "$file"
        log_action "Deleted Pixelcade script file: $file"
        pixelcade_files_found=true
    done < <(find "$scripts_dir" -type f \( -name "01-pixelcade.sh" -o -name "01-pixelcade.sh.test" \) 2>/dev/null)

    if [ "$pixelcade_files_found" = false ]; then
        log_action "No Pixelcade script files found in $scripts_dir"
    fi

    # Remove Pixelcade autostart line from autostart.sh
    if grep -qF "$pixelcade_line" "$autostart_file"; then
        sed -i "\|$pixelcade_line|d" "$autostart_file"
        log_action "Removed Pixelcade autostart line from $autostart_file"
    else
        log_action "Pixelcade autostart line not found in $autostart_file"
    fi

    log_action "Pixelcade cleanup completed."
}

# Arcade model setup function
setup_arcade_model() {
    if [ -f "$MARKER_FILE" ]; then
        local configured_model
        configured_model=$(cat "$MARKER_FILE")
        dialog --msgbox "Arcade already configured for $configured_model. Returning to menu." 10 50
        return
    fi

    # Present the arcade model selection menu with 'Select' and 'Cancel' buttons
    local arcade_model
    arcade_model=$(dialog --stdout --title "Choose Arcade Model" --menu "Select the arcade model to configure:" 15 50 6 \
        1 "RETROCADE-2P" \
        2 "RETROCADE-4P" \
        3 "MINICADE-25" \
        4 "MINICADE-32" \
        5 "MEGACADE-2P" \
        6 "MEGACADE-4P")

    # Check if the user canceled the selection
    if [ $? -ne 0 ]; then
        log_action "User canceled arcade model selection."
        return
    fi

    if [ -z "$arcade_model" ]; then
        log_action "No arcade model selected."
        return
    fi

    # Map selection number to model name
    local selected_model
    case $arcade_model in
        1) selected_model="RETROCADE-2P" ;;
        2) selected_model="RETROCADE-4P" ;;
        3) selected_model="MINICADE-25" ;;
        4) selected_model="MINICADE-32" ;;
        5) selected_model="MEGACADE-2P" ;;
        6) selected_model="MEGACADE-4P" ;;
        *) 
            dialog --msgbox "Invalid selection. Returning to menu." 10 50
            log_action "Invalid arcade model selection: $arcade_model"
            return
            ;;
    esac

    # Prompt for confirmation
    dialog --yesno "You have selected '$selected_model'. Do you want to proceed?" 10 50
    if [ $? -ne 0 ]; then
        log_action "User chose not to proceed with arcade model setup for $selected_model."
        return
    fi

    log_action "User confirmed arcade model selection: $selected_model"

    # Run cleanup functions based on selected_model
    case $selected_model in
        "RETROCADE-2P")
            cleanup_4p_collection
            cleanup_lightgun
            cleanup_spinner
            cleanup_trackball
            cleanup_pixelcade
            ;;
        "RETROCADE-4P")
            cleanup_lightgun
            cleanup_spinner
            cleanup_trackball
            cleanup_pixelcade
            ;;
        "MINICADE-25")
            cleanup_4p_collection
            cleanup_lightgun
            cleanup_spinner
            cleanup_trackball
            cleanup_pixelcade
            ;;
        "MINICADE-32")
            cleanup_lightgun
            cleanup_pixelcade
            ;;
        "MEGACADE-2P")
            cleanup_lightgun
            cleanup_pixelcade
            ;;
        "MEGACADE-4P")
            cleanup_lightgun
            cleanup_spinner
            cleanup_trackball
            cleanup_pixelcade
            ;;
        *)
            dialog --msgbox "Invalid selection. Returning to menu." 10 50
            log_action "Invalid arcade model selection: $selected_model"
            return
            ;;
    esac

    # Create marker file with the selected model name
    echo "$selected_model" > "$MARKER_FILE"
    log_action "Arcade model setup completed for $selected_model. Marker file created."
    dialog --msgbox "Arcade model setup for $selected_model completed successfully!" 10 50
}

# Clear Last Played Data function
clear_last_played_data() {
    local any_changes=false
    local gamelists=()

    # Find all gamelist.xml files under /home/pi/RetroPie/roms/
    while IFS= read -r file; do
        gamelists+=("$file")
    done < <(find /home/pi/RetroPie/roms -type f -name "gamelist.xml")

    # Add the static retropie gamelist
    gamelists+=("/opt/retropie/configs/all/emulationstation/gamelists/retropie/gamelist.xml")

    # Process each gamelist
    for gamelist in "${gamelists[@]}"; do
        if [ -f "$gamelist" ] && grep -qE '<lastplayed>|<playcount>' "$gamelist"; then
            sed -i '/<lastplayed>/d; /<playcount>/d' "$gamelist"
            log_action "Cleared lastplayed/playcount in $gamelist"
            any_changes=true
        fi
    done

    if $any_changes; then
        dialog --msgbox "Last played data cleared." 10 50
    else
        dialog --msgbox "No last played data found." 10 50
    fi
}

# Toggle UI Mode from Kiosk and Full options
toggle_ui_mode() {
    local ui_file="$EMULATIONSTATION_CONFIG/es_settings.cfg"
    local current_mode

    # Extract the current mode
    if grep -q '<string name="UIMode" value="Kiosk" />' "$ui_file"; then
        current_mode="Kiosk"
    elif grep -q '<string name="UIMode" value="Full" />' "$ui_file"; then
        current_mode="Full"
    else
        dialog --msgbox "Unable to determine current UI mode. Exiting." 10 50
        log_action "Failed to determine current UI mode from $ui_file"
        return
    fi

    # Display the current mode and confirm action
    dialog --yesno "Current UI mode is: $current_mode.\nDo you want to toggle to the other mode?" 10 50
    if [ $? -ne 0 ]; then
        log_action "User chose not to toggle UI mode. Current mode: $current_mode"
        return
    fi

    # Toggle mode
    local new_mode
    if [ "$current_mode" == "Kiosk" ]; then
        new_mode="Full"
    else
        new_mode="Kiosk"
    fi

    # Update configuration
    sudo sed -i "s|<string name=\"UIMode\" value=\"$current_mode\" />|<string name=\"UIMode\" value=\"$new_mode\" />|" "$ui_file"

    # Verify and log the change
    if grep -q "<string name=\"UIMode\" value=\"$new_mode\" />" "$ui_file"; then
        dialog --msgbox "UI mode changed to: $new_mode. A reboot is required for changes to take effect." 10 50
        log_action "Toggled UI mode from $current_mode to $new_mode"
    else
        dialog --msgbox "Failed to change UI mode to: $new_mode." 10 50
        log_action "Failed to change UI mode from $current_mode to $new_mode"
    fi
}

# Test controls function
test_controls() {
    log_action "Test controls initiated."
    python3 /home/pi/RetroPie/roms/tools/control_tester.py > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        log_action "Control tester script exited successfully."
    else
        log_action "Control tester script encountered an error."
    fi
}

# Reboot system function
reboot_system() {
    log_action "System reboot initiated."
    sudo killall -SIGTERM emulationstation || true
    sudo reboot
}

# Advanced Setup function
advanced_setup() {
    while true; do
        ADV_OPTION=$(dialog --stdout --title "Advanced Setup" --menu "Select a cleanup option:" 15 60 6 \
            1 "Remove 4P Collection" \
            2 "Remove Lightgun Games & Menu Collection" \
            3 "Remove Trackball Games & Menu Collections" \
            4 "Remove Spinner Games & Menu Collections" \
            5 "Remove Pixelcade Functionality & Files" \
            6 "Return to Main Menu")

        # Capture the exit status of the dialog
        adv_exit_status=$?

        # Check if the user canceled the menu
        if [ $adv_exit_status -ne 0 ]; then
            log_action "User canceled the Advanced Setup menu."
            break
        fi

        case $ADV_OPTION in
            1)
                if dialog --yesno "Are you sure you want to remove the 4P Collection?" 10 50; then
                    cleanup_4p_collection
                else
                    log_action "User canceled removal of 4P Collection."
                fi
                ;;
            2)
                if dialog --yesno "Are you sure you want to remove Lightgun Games & Menu Collection?" 10 60; then
                    cleanup_lightgun
                else
                    log_action "User canceled removal of Lightgun Games & Menu Collection."
                fi
                ;;
            3)
                if dialog --yesno "Are you sure you want to remove Trackball Games & Menu Collections?" 10 60; then
                    cleanup_trackball
                else
                    log_action "User canceled removal of Trackball Games & Menu Collections."
                fi
                ;;
            4)
                if dialog --yesno "Are you sure you want to remove Spinner Games & Menu Collections?" 10 60; then
                    cleanup_spinner
                else
                    log_action "User canceled removal of Spinner Games & Menu Collections."
                fi
                ;;
            5)
                if dialog --yesno "Are you sure you want to remove Pixelcade Functionality & Files?" 10 60; then
                    cleanup_pixelcade
                else
                    log_action "User canceled removal of Pixelcade Functionality & Files."
                fi
                ;;
            6)
                log_action "User chose to return to the Main Menu from Advanced Setup."
                break
                ;;
            *)
                log_action "Invalid selection in Advanced Setup: $ADV_OPTION"
                dialog --msgbox "Invalid selection. Please try again." 10 50
                ;;
        esac
    done
}

# Main menu
while true; do

	OPTION=$(dialog --stdout --title "Arcade Setup Menu" --menu "Select an option:" 15 50 7 \
		1 "Setup Arcade Model" \
		2 "Clear Last Played Data" \
		3 "Toggle EmulationStation UI Mode" \
		4 "Test Controls" \
		5 "Reboot System" \
		6 "Advanced Setup" \
		7 "Exit")

    # Capture the exit status of the dialog
    menu_exit_status=$?

    # Check if the user canceled the menu
    if [ $menu_exit_status -ne 0 ]; then
        log_action "User canceled the main menu. Exiting."
        dialog --msgbox "Exiting setup menu. Please test system prior to shipment." 10 50
        rm -f "$LOCKFILE"
        exit 0
    fi

    # Read the selected option
    case $OPTION in
        1) setup_arcade_model ;;
        2) clear_last_played_data ;;
        3) toggle_ui_mode ;;
        4) test_controls ;;
        5) reboot_system ;;
		6) advanced_setup ;;
        7) 
            log_action "Exiting setup menu."
            dialog --msgbox "Exiting setup menu. Please test system prior to shipment." 10 50
            rm -f "$LOCKFILE"
            exit 0 
            ;;
        *) 
            log_action "Invalid selection. Exiting setup menu."
            dialog --msgbox "Invalid selection. Exiting setup menu." 10 50
            rm -f "$LOCKFILE"
            exit 0 
            ;;
    esac
done
